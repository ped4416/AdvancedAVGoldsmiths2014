/* TO COMPILE THIS EXAMPLE

Using Xcode Version 5 simply drop this folder into your directory where teh "MyApps" or "Examples" folder normally is and click on the xcodeproj file. Have fun!

Basic functionality for the project taken from weeks 8, 9 and 10 of the Advanced Audiovisual Processing course at Goldsmiths College 2013. http://doc.gold.ac.uk/CreativeComputing/creativecomputation/?page_id=1200Procedural
  The main code for the pitch analysis is from Joshua Nobel's book "Interactivity 2nd Edition"
  The code to iterate through pixels is similar to openFramework examples and some that were shown in the aforementioned Audiovisual Course.
 
 The song "Gods Given Up On Him" is an origional owned by "Small Engine Repair" c 2014.  
 The texture map image "Gods" is also owned and copyrighted to "Small Engine Repair" c 2014.
 The track "nightQuiet" was downloaded from freeSound.net and has no copyright attached. 
 Feel free to use any of the code as required. Pedro Kirk Jan 2014
 Find me at www.pedrokirk.co.uk
*/