AdvancedAVGoldsmiths2014
========================

All code in here is for a Goldsmiths University module in Creative Computing. 
